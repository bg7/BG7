This zip file contains all the input files needed to run a test annotation with the system bg7 (bg7.ohnosequences.com)

The genome to annotate is the latest assembly of the strain TY-2482 of the E. coli German outbreak provided by BGI.