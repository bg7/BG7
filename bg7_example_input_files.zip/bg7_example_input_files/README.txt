17-AGO-2012

This zip file contains all the input files you need to run a test annotation with the system bg7 (bg7.ohnosequences.com)

- escherichia_coli_o104_h4_str._ty-2482_1_supercontigs.fasta FASTA file with the bacterial genome to annotate. 
- EHEC_Reference_RNAs.frn FASTA file with the reference RNAs
- EHEC_ReferenceProteins_17_08_2012.fasta FASTA file with the reference proteins
- genetic_code.txt Text file containing the genetic code
- GenBankExternalData.xml XML file with additional data needed to get the genbank files
